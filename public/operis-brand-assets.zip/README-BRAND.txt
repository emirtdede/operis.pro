﻿OPERIS BRAND ASSETS & MEDIA KIT
===============================
Platform: Operis (Operated by Vellium)
Headquarters: Sisli, Istanbul, Turkey
Official Domain: https://operis.pro
Official Inquiries: contact@vellium.dev

INCLUDED ASSETS:
1. operis-logo-koyu.svg   - Dark theme vector logo (Platinum White #FAFAFA, transparent background)
2. operis-logo-acik.svg   - Light theme vector logo (Obsidian Black #09090B, transparent background)
3. operis-favicon.svg     - 4-band calibrated O Stream Mark vector symbol
4. apple-touch-icon.png   - 180x180 high-res application icon

COLOR CODES:
- Obsidian Black: #09090B (rgb: 9, 9, 11)
- Platinum White: #FAFAFA (rgb: 250, 250, 250)
- Brand Blue:     #3B82F6 (rgb: 59, 130, 246)
- Engineering:    #6366F1 (rgb: 99, 102, 241)
- Cyber Emerald:  #10B981 (rgb: 16, 185, 129)

USAGE RESTRICTIONS:
- Do not stretch, alter aspect ratios, or warp vector proportions.
- Wordmark is strictly lowercase 'peris' in Inter Bold. All-caps 'PERIS' is prohibited.
- Maintain clear space equal to at least 50% of logo height around marks.
